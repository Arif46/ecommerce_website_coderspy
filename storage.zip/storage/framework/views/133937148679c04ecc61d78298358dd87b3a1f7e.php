<?php /* E:\xampp\htdocs\myfrag\resources\views/supplier/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="col-lg-12">
    <div class="panel">
        <div class="panel-heading">
            <h3 class="panel-title"><?php echo e(__('Add Supplier')); ?></h3>
        </div>

        <!--Horizontal Form-->
        <!--===================================================-->
        <form class="form-horizontal" action="<?php echo e(route('supplier.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="panel-body">

                <div class="form-group start_div">
                    <input name="active_status" type="hidden" value="1">
                  
                    <div class="col-sm-6">
                          <label><?php echo e(__('Supplier Name')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Supplier Name')); ?>" id="supplier_name" name="supplier_name" class="form-control <?php echo e($errors->has('Supplier Name') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Supplier Name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                   
                    <div class="col-sm-6">
                          <label><?php echo e(__('Contact Name')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Contact Name')); ?>" id="contact_name" name="contact_name" class="form-control <?php echo e($errors->has('Contact Name') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Contact Name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('Designation')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Designation')); ?>" id="designation" name="designation" class="form-control <?php echo e($errors->has('Designation') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Designation')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('Address')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Address')); ?>" id="address" name="address" class="form-control <?php echo e($errors->has('Address') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Address')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('City')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('City')); ?>" id="city" name="city" class="form-control <?php echo e($errors->has('City') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('City')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('Country')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Country')); ?>" id="country" name="country" class="form-control <?php echo e($errors->has('Country') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Country')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('Mobile Number')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Mobile Number')); ?>" id="mobile_number" name="mobile_number" class="form-control <?php echo e($errors->has('Mobile Number') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Mobile Number')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('Telephone Number')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Telephone Number')); ?>" id="telephone_number" name="telephone_number" class="form-control <?php echo e($errors->has('Telephone Number') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Telephone Number')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('Fax Number')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Fax Number')); ?>" id="fax_number" name="fax_number" class="form-control <?php echo e($errors->has('Fax Number') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Fax Number')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('Email')); ?></label>
                        <input type="email" placeholder="<?php echo e(__('Email')); ?>" id="email" name="email" class="form-control <?php echo e($errors->has('Email') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('Trade License')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('Trade License')); ?>" id="trade_license" name="trade_license" class="form-control <?php echo e($errors->has('Trade License') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('Trade License')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="col-sm-6">
                          <label><?php echo e(__('VAT Registration Number')); ?></label>
                        <input type="text" placeholder="<?php echo e(__('VAT Registration Number')); ?>" id="vat_reg_no" name="vat_reg_no" class="form-control <?php echo e($errors->has('VAT Registration Number') ? ' is-invalid' : ''); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong style="color: red"><?php echo e($errors->first('VAT Registration Number')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                     
                    
                
                </div>
               
              <div class="panel-footer text-right">
                <button class="btn btn-purple" type="submit"><?php echo e(__('Save')); ?></button>
            </div>
           
            </div>
           
        </form>
        <!--===================================================-->
        <!--End Horizontal Form-->

    </div>
</div>

   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>