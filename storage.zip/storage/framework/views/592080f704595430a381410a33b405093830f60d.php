<?php /* E:\xampp\htdocs\myfrag\resources\views/supplier/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-sm-12">
        <a href="<?php echo e(route('supplier.create')); ?>" class="btn btn-rounded btn-info pull-right"><?php echo e(__('Add supplier')); ?></a>
    </div>

   <div class="col-sm-2"></div>
    <div class="col-sm-3">
        <form action="<?php echo e(route('taxImport')); ?>" method="POST" name="importform" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" name="file" class="form-control" required>
    </div>
    <div class="col-sm-6">
        <button class="btn btn-success">Import Excel Sheet</button>
     
    </div>
    </form>
</div>
<br>

<!-- Basic Data Tables -->
<!--===================================================-->
<div class="panel">
    <div class="panel-heading bord-btm clearfix pad-all h-100">
        <h3 class="panel-title pull-left pad-no"><?php echo e(__('Manage Supplier')); ?></h3>
        <div class="pull-right clearfix">
            <form class="" id="sort_brands" action="<?php echo e(route('supplier.search')); ?>" method="POST">
                <div class="box-inline pad-rgt pull-left">
                    <div class="" style="min-width: 200px;">
                        <input type="text" class="form-control" required id="search" name="search" placeholder=" Type name & Enter">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="panel-body">
        <table class="table table-striped res-table mar-no" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th><?php echo e(__('Id')); ?></th>
                    <th><?php echo e(__('Name')); ?></th>
                    <th><?php echo e(__('Contact Name')); ?></th>
                    <th><?php echo e(__('Designation')); ?></th>
                    <th><?php echo e(__('Address')); ?></th>
                    <th><?php echo e(__('City')); ?></th>
                    <th><?php echo e(__('Country')); ?></th>
                    <th><?php echo e(__('Mobile No.')); ?></th>
                    <th><?php echo e(__('Telephone No.')); ?></th>
                    <th><?php echo e(__('Fax No.')); ?></th>
                    <th><?php echo e(__('Email')); ?></th>
                    <th><?php echo e(__('Trade License')); ?></th>
                    <th><?php echo e(__('VAT Reg. No.')); ?></th>
                    <th><?php echo e(__('Created By')); ?></th>
                    <th><?php echo e(__('Updated By')); ?></th>
                    <th><?php echo e(__('Status')); ?></th>
                    <th width="10%"><?php echo e(__('Options')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php  $i=1;?>
                <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(@$s->id); ?></td>
                        <td><?php echo e(@$s->supplier_name); ?></td>
                        <td><?php echo e(@$s->Contact_name); ?></td>
                        <td><?php echo e(@$s->designation); ?></td>
                        <td><?php echo e(@$s->address); ?></td>
                        <td><?php echo e(@$s->city); ?></td>
                        <td><?php echo e(@$s->country); ?></td>
                        <td><?php echo e(@$s->mobile_number); ?></td>
                        <td><?php echo e(@$s->telephone_number); ?></td>
                        <td><?php echo e(@$s->fax_number); ?></td>
                        <td><?php echo e(@$s->email); ?></td>
                        <td><?php echo e(@$s->trade_license); ?></td>
                        <td><?php echo e(@$s->vat_reg_no); ?></td>
                        <td><?php echo e(@$s->created_by); ?></td>
                        <td><?php echo e(@$s->updated_by); ?></td>
                        <td>
                            <?php if($s->status == '0'): ?>
                                <span class="badge badge-pill badge-danger" style="padding: 10px;">Deavtive</span>
                            <?php else: ?>
                                <span class="badge badge-pill badge-success" style="padding: 10px;">Active</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group dropdown">
                                <button class="btn btn-primary dropdown-toggle dropdown-toggle-icon" data-toggle="dropdown" type="button">
                                    <?php echo e(__('Actions')); ?> <i class="dropdown-caret"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-right">
                                    <li><a href="<?php echo e(route('supplier.edit', encrypt(@$s->id))); ?>"><?php echo e(__('Edit')); ?></a></li>
                                    <li><a onclick="confirm_modal('<?php echo e(route('supplier.destroy', @$s->id)); ?>');"><?php echo e(__('Delete')); ?></a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
      
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        function sort_brands(el){
            $('#sort_brands').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>