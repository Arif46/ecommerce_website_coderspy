<?php /* E:\xampp\htdocs\myfrag\resources\views/frontend/inc/customer_side_nav.blade.php */ ?>
<div class="sidebar sidebar--style-3 no-border stickyfill p-0">
    <div class="widget mb-0">
        <div class="widget-profile-box text-center p-3">
            <?php if(Auth::user()->avatar_original != null): ?>

                <img src="<?php echo e(url('public/')); ?>/<?php echo e(Auth::user()->avatar_original); ?>" class="image rounded-circle customer_image">

            <?php else: ?>
                <img src="<?php echo e(url('public/')); ?>/frontend/images/user.png" class="image rounded-circle customer_image">
            <?php endif; ?>
            <div class="name"><?php echo e(Auth::user()->name); ?></div>
        </div>
        <div class="sidebar-widget-title py-3">
            <span><?php echo e(__('Menu')); ?></span>
        </div>
        <div class="widget-profile-menu py-3">
            <ul class="categories categories--style-3">
                <li>
                    <a href="<?php echo e(route('customerDashboard')); ?>" class="<?php echo e(areActiveRoutesHome(['customerDashboard'])); ?>">
                        <i class="la la-dashboard"></i>
                        <span class="category-name">
                            <?php echo e(__('Dashboard')); ?>

                        </span>
                    </a>
                </li>
                <?php
                $delivery_viewed = App\Order::where('user_id', Auth::user()->id)->where('delivery_viewed', 0)->get()->count();
                $payment_status_viewed = App\Order::where('user_id', Auth::user()->id)->where('payment_status_viewed', 0)->get()->count();
                $refund_request_addon = \App\Addon::where('unique_identifier', 'refund_request')->first();
                $club_point_addon = \App\Addon::where('unique_identifier', 'club_point')->first();
                ?>
                
                   <li>
                    <a href="<?php echo e(url('customer-purchase-history')); ?>" class="<?php echo e(areActiveRoutesHome(['purchase_history.index'])); ?>">
                        <i class="la la-file-text"></i>
                        <span class="category-name">
                            <?php echo e(__('Purchase History')); ?> <?php if($delivery_viewed > 0 || $payment_status_viewed > 0): ?><span class="ml-2" style="color:green"><strong>(<?php echo e(__('New Notifications')); ?>) </strong></span><?php endif; ?>
                        </span>
                    </a>
                </li>

                <?php if($refund_request_addon != null && $refund_request_addon->activated == 1): ?>
                    <li>
                        <a href="<?php echo e(route('customer_refund_request')); ?>" class="<?php echo e(areActiveRoutesHome(['customer_refund_request'])); ?>">
                            <i class="la la-file-text"></i>
                            <span class="category-name">
                                <?php echo e(__('Sent Refund Request')); ?>

                            </span>
                        </a>
                    </li>
                <?php endif; ?>

              
                  <li>
                    <a href="<?php echo e(url('customer-wishlists')); ?>" class="">
                        <i class="la la-heart-o"></i>
                        <span class="category-name">
                            <?php echo e(__('Wishlist')); ?>

                        </span>
                    </a>
                </li>
              
                  <?php if(\App\BusinessSetting::where('type', 'conversation_system')->first()->value == 1): ?>
                    <?php
                        $conversation = \App\Conversation::where('sender_id', Auth::user()->id)->where('sender_viewed', 0)->get();
                    ?>
                    <li>
                        <a href="<?php echo e(url('customer-conversations')); ?>" class="<?php echo e(areActiveRoutesHome(['conversations.index', 'conversations.show'])); ?>">
                            <i class="la la-comment"></i>
                            <span class="category-name">
                                <?php echo e(__('Conversations')); ?>

                                <?php if(count($conversation) > 0): ?>
                                    <span class="ml-2" style="color:green"><strong>(<?php echo e(count($conversation)); ?>)</strong></span>
                                <?php endif; ?>
                            </span>
                        </a>
                    </li>
                <?php endif; ?>
              
                 <li>
                    <a href="<?php echo e(url('customer-profile')); ?>" class="<?php echo e(areActiveRoutesHome(['profile'])); ?>">
                        <i class="la la-user"></i>
                        <span class="category-name">
                            <?php echo e(__('Manage Profile')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(url('my-blend')); ?>" class="<?php echo e(areActiveRoutesHome(['my-blend'])); ?>">
                        <i class="la la-user"></i>
                        <span class="category-name">
                            <?php echo e(__('My Blends')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(url('subscription/queue')); ?>" class="<?php echo e(areActiveRoutesHome(['my-subscription'])); ?>">
                        <i class="la la-user"></i>
                        <span class="category-name">
                            <?php echo e(__('My Subscriptions')); ?>

                        </span>
                    </a>
                </li>
                  <li>
                    <a href="<?php echo e(url('my-compare-list')); ?>" class="<?php echo e(areActiveRoutesHome(['my-compare-list'])); ?>">
                        <i class="la la-user"></i>
                        <span class="category-name">
                            <?php echo e(__('My Compare List')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(url('my-sample')); ?>" class="<?php echo e(areActiveRoutesHome(['my-sample'])); ?>">
                        <i class="la la-user"></i>
                        <span class="category-name">
                            <?php echo e(__('My Samples')); ?>

                        </span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(url('my-orders')); ?>" class="<?php echo e(areActiveRoutesHome(['my-orders'])); ?>">
                        <i class="la la-user"></i>
                        <span class="category-name">
                            <?php echo e(__('My Orders')); ?>

                        </span>
                    </a>
                </li>









                <li>
                    <a href="<?php echo e(url('recently-viewed')); ?>" class="<?php echo e(areActiveRoutesHome(['recently-viewed'])); ?>">
                        <i class="la la-user"></i>
                        <span class="category-name">
                            <?php echo e(__('Recently Viewed')); ?>

                        </span>
                    </a>
                </li>

                <?php if(\App\BusinessSetting::where('type', 'wallet_system')->first()->value == 1): ?>
                    <li>
                        <a href="<?php echo e(route('wallet.index')); ?>" class="<?php echo e(areActiveRoutesHome(['wallet.index'])); ?>">
                            <i class="la la-dollar"></i>
                            <span class="category-name">
                                <?php echo e(__('My Wallet')); ?>

                            </span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if($club_point_addon != null && $club_point_addon->activated == 1): ?>
                    <li>
                        <a href="<?php echo e(route('earnng_point_for_user')); ?>" class="<?php echo e(areActiveRoutesHome(['earnng_point_for_user'])); ?>">
                            <i class="la la-dollar"></i>
                            <span class="category-name">
                                <?php echo e(__('Earning Points')); ?>

                            </span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(\App\Addon::where('unique_identifier', 'affiliate_system')->first() != null && \App\Addon::where('unique_identifier', 'affiliate_system')->first()->activated && Auth::user()->affiliate_user != null && Auth::user()->affiliate_user->status): ?>
                    <li>
                        <a href="<?php echo e(route('affiliate.user.index')); ?>" class="<?php echo e(areActiveRoutesHome(['affiliate.user.index', 'affiliate.payment_settings'])); ?>">
                            <i class="la la-dollar"></i>
                            <span class="category-name">
                                <?php echo e(__('Affiliate System')); ?>

                            </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php
                    $support_ticket = DB::table('tickets')
                                ->where('client_viewed', 0)
                                ->where('user_id', Auth::user()->id)
                                ->count();
                ?>
               
                 <li>
                    <a href="<?php echo e(url('customer-support-ticket')); ?>" class="<?php echo e(areActiveRoutesHome(['support_ticket.index'])); ?>">
                        <i class="la la-support"></i>
                        <span class="category-name">
                            <?php echo e(__('Support Ticket')); ?> <?php if($support_ticket > 0): ?><span class="ml-2" style="color:green"><strong>(<?php echo e($support_ticket); ?> <?php echo e(__('New')); ?>)</strong></span></span><?php endif; ?>
                        </span>
                    </a>
                </li>
            </ul>
        </div>
        <?php if(\App\BusinessSetting::where('type', 'vendor_system_activation')->first()->value == 1): ?>
            <div class="widget-seller-btn pt-4">
                <a href="<?php echo e(route('shops.create')); ?>" class="btn btn-anim-primary w-100"><?php echo e(__('Be A Seller')); ?></a>
            </div>
        <?php endif; ?>
    </div>
</div>
